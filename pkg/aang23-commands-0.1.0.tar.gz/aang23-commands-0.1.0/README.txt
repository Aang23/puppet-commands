This README and the documentation will be redacted soon.
The only goal of this module is to be a "exec" wrapper for hiera.
All parameters are not implemented yet, but this is upcoming.
